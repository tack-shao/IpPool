# -*- coding: utf-8 -*-
# @时间      :2019/3/26 下午5:03
# @作者      :tack
# @网站      :
# @文件      :conf.py
# @说明      :


# aes crypt key
data_crypt_key = '12345678abcdefgh'