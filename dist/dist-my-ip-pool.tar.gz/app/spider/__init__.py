# -*- coding: utf-8 -*-
# @时间      :2019/3/23 上午12:27
# @作者      :tack
# @网站      :
# @文件      :__init__.py.py
# @说明      :

from .IpPool import IpPool

ip_pool_handle = IpPool()